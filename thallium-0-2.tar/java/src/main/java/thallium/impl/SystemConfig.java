package thallium.impl;

public abstract class SystemConfig implements Comparable<SystemConfig> {
    public abstract String[] getStringValues();
}